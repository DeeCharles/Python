from flask import render_template, redirect, session, request

# line below is to invoke class methods
from flask_app.models import user

from flask_app import app

# import the class from user.py
# from user import User

@app.route('/') 
def index():
    users = user.User.get_all_users()
    print(users)
    return render_template("read.html", all_users = users)

@app.route('/new/users')
def new_user():
    return render_template("create.html")

@app.route("/add/user", methods=["POST"])
def add_user():
    print("Hello", request.form)
    # print(Name.request.form["name"])
    user.User.create_user(request.form)
    return redirect ("/")

@app.route("/delete/user/<int:id>")
def delete_user(id):
    user.User.delete_user(id)
    return redirect("/")


# @app.route("/users/<id>")
# def get_user(id):
#     one_user=user.User.get.user_by_id(id)
#     return render_template ("create.html", one_user=one_user)