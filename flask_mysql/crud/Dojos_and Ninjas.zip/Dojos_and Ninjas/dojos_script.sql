INSERT INTO dojos (name)
VALUES ('Seattle'),('San Jose'),('Burbank'),('OC'),
('Dallas'), ('Boise'), ('Chicago'), ('DC');
SELECT * FROM dojos;
INSERT INTO ninjas (dojo_id,first_name,last_name,age)
VALUES (1,'Todd','Enders',26), (3,'Speros','Misrick',28), (4,'Donovan','An', 27),(7,'Phil','Krul',31);
SELECT * FROM ninjas;